#CANONICAL
DOCS_INDEX_v2.5.md
(This is the authoritative index and LLM-access guide for all StableNew documentation.)

Executive Summary (8–10 lines)

This index defines the entire canonical documentation set for StableNew v2.5.
All authoritative documents are identified, categorized, and described in one place.
AI agents and human contributors must use only the #CANONICAL files listed here when making decisions, writing PRs, or reviewing architectural or governance changes.
All deprecated or outdated documents are relocated to /docs/archive/ and labeled with #ARCHIVED, which prohibits their usage in future reasoning.
This index establishes the LLM Access Layer, enabling deterministic, drift-free interpretation of project structure.
All future documentation updates must register here to maintain stability and clarity.

PR-Relevant Facts (Quick Reference)

Canonical docs MUST start with #CANONICAL.

Archived docs MUST start with #ARCHIVED and MUST be ignored by agents.

Only documents in this index may be referenced for PRs or architectural decisions.

Canonical filenames must end with v2.5.md.

The index is the single source of truth for documentation hierarchy.

Agents must begin all reasoning from this document.

============================================================

0. TLDR / BLUF — Quick Navigation

============================================================

Canonical Documents (Authoritative)
Category	Document
Architecture	ARCHITECTURE_v2.5.md
Governance	Governance_v2.5.md
Roadmap	Roadmap_v2.5.md
Agent Instructions	StableNew_Agent_Instructions_v2.5.md
Coding & Testing	StableNew_Coding_and_Testing_v2.5.md (future PR)
Randomizer Spec	Randomizer_Spec_v2.5.md (future PR)
Learning System	Learning_System_Spec_v2.5.md (future PR)
Cluster Compute	Cluster_Compute_Spec_v2.5.md (future PR)
Archive Documents (For historical context only)

Anything in:
docs/archive/
or labeled:
#ARCHIVED

LLM Access Rules

Agents must:

Use ONLY canonical docs

Ignore all archived docs

Never reference a doc not listed here

Start analysis with this index

============================================================

1. Purpose of This Index

============================================================

This document:

Enumerates all valid documentation for v2.5+

Defines canonical vs archived documents

Provides metadata for LLMs to correctly load and prioritize files

Provides human contributors with a consistent starting point

Ensures that architecture, governance, and roadmap information stays unified

Prevents duplication and fragmentation of knowledge

============================================================

2. LLM Access Layer (Machine-Readable Metadata)

============================================================

Agents MUST use this structured metadata:

canonical_pattern: "*-v2.5.md"
archive_directory: "docs/archive/"
canonical_header: "#CANONICAL"
archive_header: "#ARCHIVED"

priority_order:
  1: ARCHITECTURE_v2.5.md
  2: Governance_v2.5.md
  3: Roadmap_v2.5.md
  4: StableNew_Agent_Instructions_v2.5.md
  5: Subsystem specs (Randomizer, Learning, Cluster)


Additional Required Sections for Canonical Docs:

required_sections:
  - Executive Summary
  - PR-Relevant Facts


============================================================

3. Canonical Document Categories

============================================================

Each category lists documents that are current, active, and authoritative.

3.1 Architecture
ARCHITECTURE_v2.5.md — Canonical

Defines:

System architecture

Component boundaries

Pipeline job lifecycle

GUI/Controller/Pipeline/Queue/Runner structure

Stage ordering

Deprecated architecture appendix

This is the top-priority canonical document.

3.2 Governance
Governance_v2.5.md — Canonical

Defines:

PR rules

Subsystem boundaries

Risk tiers

Testing expectations

Documentation governance

Conflict resolution

Rollback rules

Agents MUST check this before generating PRs.

3.3 Roadmap
Roadmap_v2.5.md — Canonical

Defines:

Phase 1 (Stabilization)

Phase 2 (Learning System)

Phase 3 (Cluster Compute)

PR grouping (200s–600s series)

Dependencies and sequencing

Completion criteria

Agents must use this file before proposing future PR bundles.

3.4 Agent Instructions
StableNew_Agent_Instructions_v2.5.md — Canonical

Defines:

How AI agents should reason

How to consult canonical docs

How to avoid drift, hallucinations, and boundary violations

How to structure PRs

When to ask for snapshots or clarification

This file governs all agent behavior.

3.5 Coding & Testing Standards
StableNew_Coding_and_Testing_v2.5.md — Canonical (pending PR-DOC-306)

Will define:

Coding conventions

Testing strategy

Smoke test protocols

WebUI interaction guidelines

Example tests for pipeline, GUI, and queue subsystems

3.6 Subsystem Specifications

The following files are canonical once created:

Randomizer

Randomizer_Spec_v2.5.md
Defines engine, plan schema, GUI controls, preview injection, and controller integration.

Learning System

Learning_System_Spec_v2.5.md
Defines JSONL schema, LearningRecord, metrics, job history, and signal injection.

Cluster Compute

Cluster_Compute_Spec_v2.5.md
Defines remote execution, workers, scheduling, caching, and failure semantics.

============================================================

4. Archive Index

============================================================

All documents in this section:

Are NOT to be referenced

MUST NOT be used in PRs

Exist only for historical transparency

Are clearly tagged with #ARCHIVED

Have been replaced by canonical v2.5 documents

Archive Directory:
docs/archive/

Example Archived Files:

Legacy V1 MainWindow documentation

Old architecture drafts

Outdated roadmap fragments

Deprecated governance notes

Early internal diagrams

Partial subsystem design files

Agents must ignore all of these.

============================================================

5. How to Use This Index (Human Developers)

============================================================

Developers:

Start with Roadmap_v2.5 to identify phase + PR targets

Consult Architecture_v2.5 to ensure alignment

Consult Governance_v2.5 for boundaries and rules

Optionally consult subsystem specs depending on PR scope

Update this document when adding new canonical docs

Only files listed here may influence design decisions.

============================================================

6. How to Use This Index (AI Agents)

============================================================

Agents must follow this strict workflow:

Load DOCS_INDEX_v2.5.md first

Load all canonical documents referenced here

Ignore all others

Build reasoning from:

Architecture_v2.5.md

Governance_v2.5.md

Roadmap_v2.5.md

Subsystem specs

Reject or ask for clarification if:

Requested action contradicts canonical docs

Snapshot is missing

File paths unclear

Apply PR guardrails from Governance_v2.5

Apply subsystem boundaries from Architecture_v2.5

Apply sequencing from Roadmap_v2.5

Agents must NEVER:

Invent API names

Guess architecture

Modify forbidden files

Use archived documents

============================================================

7. Document Update Rules

============================================================

7.1 Adding new canonical documents

Must include #CANONICAL

Must include Executive Summary + PR Facts

Must be added to this index

Must follow naming pattern *-v2.5.md

7.2 Archiving documents

Move to /docs/archive/

Add #ARCHIVED at top

Remove from index

7.3 Editing canonical docs

Requires PR with tests when rules affect behavior

Requires architectural validation

Must maintain cross-document consistency

============================================================

8. Canonical Document Map (Hyperlinks)

============================================================

docs/
  ├── ARCHITECTURE_v2.5.md
  ├── Governance_v2.5.md
  ├── Roadmap_v2.5.md
  ├── StableNew_Agent_Instructions_v2.5.md
  ├── StableNew_Coding_and_Testing_v2.5.md     (pending)
  ├── Randomizer_Spec_v2.5.md                  (pending)
  ├── Learning_System_Spec_v2.5.md             (pending)
  ├── Cluster_Compute_Spec_v2.5.md             (pending)
  └── archive/


Agents must treat all files outside docs/ and not ending in v2.5.md as non-authoritative unless specified by PR.

============================================================

9. Deprecated Indexes (Archived)

============================================================
#ARCHIVED
(Agents must ignore.)

Deprecated:

All pre-v2.5 documentation sets

All multi-file architecture attempts

All pre-LLM-governance index documents

Roadmap fragments replaced by Roadmap_v2.5.md

V1/V2.0 guides not versioned properly

End of DOCS_INDEX_v2.5.md