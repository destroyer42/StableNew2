# Legacy theming module (V1 / hybrid).
# Kept only for historical reference; V2 GUI uses src.gui.theme_v2 instead.
"""Shared theming helpers for StableNew GUIs."""
...existing code...
# Moved to archive November 28, 2025
# Legacy theme

