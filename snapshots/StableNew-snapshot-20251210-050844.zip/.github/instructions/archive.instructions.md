# Archive Folder Instructions

This folder contains V1 / legacy modules.

## Hard Rules
- Do NOT modify these files.
- Do NOT import these files into active V2 code.
- Use only as reference when migrating old features.

All new work must target the V2 or V2.5 modules.