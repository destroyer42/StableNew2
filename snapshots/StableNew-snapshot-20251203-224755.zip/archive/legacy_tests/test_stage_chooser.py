"""Starter RED test for per-image StageChooser modal.
Created: 2025-11-02 22:31:47
"""

# def test_modal_returns_choice_without_blocking_loop(tk_root):
#     raise AssertionError("Implement: modal shows preview, returns a choice (img2img/ADetailer/upscale/none)")
