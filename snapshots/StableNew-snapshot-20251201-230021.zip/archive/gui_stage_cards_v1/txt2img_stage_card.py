"""
Legacy txt2img stage card archived to `archive/gui_v1/txt2img_stage_card.py`.

Phase-1:
    Use the V2 stage cards (`advanced_txt2img_stage_card_v2`, etc.).
"""

from __future__ import annotations

# Empty stub — no runtime behavior.
