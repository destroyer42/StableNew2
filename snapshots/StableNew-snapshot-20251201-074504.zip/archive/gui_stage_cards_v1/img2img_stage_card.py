# This legacy Img2Img stage card has been archived to archive/gui_v1/img2img_stage_card.py
# It is kept as a stub to prevent new code from depending on it.

