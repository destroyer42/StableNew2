# Codex Safety Wrapper Template

```
BEGIN SAFETY WRAPPER
<insert guidance for Codex safety wrapper usage>
END SAFETY WRAPPER
```
