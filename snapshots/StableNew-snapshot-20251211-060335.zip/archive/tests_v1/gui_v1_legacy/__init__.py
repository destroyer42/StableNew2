# Enable pytest discovery for the tests.gui package
