# PR-SAFE-ISOLATION-001: Codex Safety Wrapper & GUI Utils Isolation

## Summary
Ensure src.utils randomizer imports are GUI-free and add safety wrapper template.
