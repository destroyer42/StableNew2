# Archived pipeline_config PR templates (PR-CORE1-13)

These templates describe the pre-v2.6, pipeline_config-driven architecture. They are **archived** and **must not be used**. See `docs/PR Template — StableNew v2.6.md` for the canonical template and NJR + PromptPack-only workflow.
