%PDF-1.4
%���� ReportLab Generated PDF document http://www.reportlab.com
1 0 obj
<<
/F1 2 0 R /F2 3 0 R
>>
endobj
2 0 obj
<<
/BaseFont /Helvetica /Encoding /WinAnsiEncoding /Name /F1 /Subtype /Type1 /Type /Font
>>
endobj
3 0 obj
<<
/BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding /Name /F2 /Subtype /Type1 /Type /Font
>>
endobj
4 0 obj
<<
/Contents 8 0 R /MediaBox [ 0 0 595.2756 841.8898 ] /Parent 7 0 R /Resources <<
/Font 1 0 R /ProcSet [ /PDF /Text /ImageB /ImageC /ImageI ]
>> /Rotate 0 /Trans <<

>> 
  /Type /Page
>>
endobj
5 0 obj
<<
/PageMode /UseNone /Pages 7 0 R /Type /Catalog
>>
endobj
6 0 obj
<<
/Author (\(anonymous\)) /CreationDate (D:20251128130620+00'00') /Creator (\(unspecified\)) /Keywords () /ModDate (D:20251128130620+00'00') /Producer (ReportLab PDF Library - www.reportlab.com) 
  /Subject (\(unspecified\)) /Title (\(anonymous\)) /Trapped /False
>>
endobj
7 0 obj
<<
/Count 1 /Kids [ 4 0 R ] /Type /Pages
>>
endobj
8 0 obj
<<
/Filter [ /ASCII85Decode /FlateDecode ] /Length 250
>>
stream
GasJK_$\%5&4H!cME.\Ec,PY2Wi-_"K`"*^=<f/pD$9Cph:=(>70`H@42W"h?r;:F*gg`%<WnT47o5L`cl4NYE_WM0S172g8sPho:9YmFUWO7qd\i+XSuX,-2-!O473j9-3Do//"+#kL7!k!IQI1!P0[UU9l^Kug54f_=JDk^(6$B>J(chT2r*!S#QW(UXH*V*2\"#U0E]*EB"SQ/.N!hN:*N_9:jOW&s;9-gIRlaiPDrM6=aV1c0;iC~>endstream
endobj
xref
0 9
0000000000 65535 f 
0000000073 00000 n 
0000000114 00000 n 
0000000221 00000 n 
0000000333 00000 n 
0000000536 00000 n 
0000000604 00000 n 
0000000887 00000 n 
0000000946 00000 n 
trailer
<<
/ID 
[<795c4c96da788619405b7fb35505398b><795c4c96da788619405b7fb35505398b>]
% ReportLab generated PDF document -- digest (http://www.reportlab.com)

/Info 6 0 R
/Root 5 0 R
/Size 9
>>
startxref
1286
%%EOF
