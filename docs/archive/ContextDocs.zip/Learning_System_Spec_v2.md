# Learning System Spec v2  
_Hybrid Passive + Active Learning (L3)_

---

## 1. Overview

The Learning System makes StableNew **self‑improving** over time by turning each run into signal about “what works” for a given style, prompt, and pipeline config.

It supports:

- **Passive Learning** – user runs pipelines normally, optionally rating outputs after the fact.
- **Active Learning (Learning Runs)** – the system proposes controlled experiments for a single variable (e.g., steps), and the user rates the resulting grid.
- **Hybrid (L3)** – user can switch between passive‑only and active learning mode per session or per pack.

Learning is **backend‑agnostic**: it works the same whether the pipeline is executed on a single machine or distributed across the cluster.

---

## 2. Data Structures

### 2.1 LearningRecord

A **LearningRecord** captures a single pipeline run (or a single variant from a randomizer/learning run). It includes:

- Run context
  - run_id
  - timestamp
  - prompt_pack_id / prompt_id
  - stage sequence used
  - whether the run was interactive or batch

- Configuration snapshot
  - Full effective **PipelineConfig** used for the run (all stages).
  - Any randomizer metadata (variant index, matrix values used).
  - Learning mode info (passive vs active, plan id).

- Outputs
  - Paths or IDs of images produced (per stage where relevant).
  - Derived metrics (e.g., size, sampler, steps, CFG).

- User feedback (optional at first)
  - rating (e.g., 1–5)
  - tags (too noisy, too smooth, great composition, bad anatomy, etc.).

The record is written via **LearningRecordWriter** as **append‑only JSONL**, enabling later analysis and LLM consumption.

### 2.2 LearningPlan and LearningRunStep

A **LearningPlan** defines a structured experiment, usually focused on a single variable:

- plan_id
- focus_parameter (e.g., "txt2img.steps")
- base_config (PipelineConfig compatible structure)
- variant_values (e.g., [15, 20, 25, 30, 35])
- images_per_variant (e.g., 1–3)
- metadata (who triggered the plan, when, any notes).

A **LearningRunStep** is a concrete execution step derived from a plan:

- step_id
- plan_id
- variant_index
- config_for_step (base_config + focused override value)
- stage sequence
- output references.

### 2.3 LearningRunResult

A **LearningRunResult** aggregates records and feedback for an entire LearningPlan:

- plan_id
- steps: list of (step_id, rating, tags)
- summary stats (best performing value, spread of ratings, etc.).

---

## 3. Passive Learning Workflow

1. User runs a normal pipeline (with or without randomizer).
2. PipelineRunner produces outputs and (if learning is enabled) emits a **LearningRecord** for the run/variant.
3. GUI optionally prompts the user to rate the result:
   - Immediately after the run.
   - Or later via a “Review recent runs” screen.
4. Updated ratings are merged back into the LearningRecord.

Key properties:

- Minimal UX overhead – user can ignore learning if they choose.
- Records are still valuable, even if they remain unrated (for future inspection).

---

## 4. Active Learning Workflow (Learning Runs)

A **Learning Run** is a user‑initiated, controlled experiment that varies one variable at a time.

### 4.1 Setup

- User selects:
  - Prompt pack / prompt to focus on.
  - Stage to test (typically txt2img first, later possibly img2img or upscale).
  - Parameter to vary (steps, CFG, sampler, scheduler, denoising_strength, etc.).
  - Range of values (e.g., steps: 15–45 in increments of 5).
  - Images per variant (1–3).

- StableNew builds a **LearningPlan** based on these inputs.

### 4.2 Execution

- LearningRunner feeds each **LearningRunStep** into the pipeline (either local or distributed via the cluster).
- For txt2img example:
  - All non‑focus parameters (model, LoRAs, CFG, etc.) stay fixed.
  - Only steps changes across variants.

- Outputs are grouped for easy visual comparison (e.g., 3x3 grid).

### 4.3 Feedback Collection

- After the run, the user sees the set of variants (organized by the focus parameter value).
- For each value, the user can:
  - Rate the result (1–5).
  - Add quick tags.
- LearningRunResult is stored and aggregated.

### 4.4 Insights and Preset Updates

- A minimal, local insights layer can show:
  - Which parameter values scored best for this prompt pack.
  - Trends over time.
- Optionally, new **preset configs** can be generated, e.g.:
  - “For this pack, use 30–35 steps and CFG ~7–8 as the default one‑click setting.”

---

## 5. Hybrid Mode (L3)

L3 combines the above:

- Each run can be configured to:
  - Use **passive learning only** (record + optional rating).
  - Trigger an **active Learning Run** (per‑param experiment).

- Settings can be per‑project or per‑pack:
  - Example: heroic fantasy pack is in “Learning mode” while a comic‑style pack is “locked in” and mainly uses randomizer variants.

---

## 6. Integration Points

### 6.1 GUI

- Settings / toggle:
  - Global “Enable learning” checkbox.
  - Learning mode selector: Off / Passive only / Passive + Active.
- Per‑run options:
  - “Capture learning record for this run” checkbox.
  - “Convert this run into a Learning Run” button when applicable.

- Learning UI:
  - A simple “Review & Rate Recent Runs” dialog.
  - A “Create Learning Run” wizard.

### 6.2 Controller & Pipeline

- Controller decides:
  - Whether a given run should produce LearningRecords.
  - Whether it should be treated as a LearningRunStep vs normal run.

- PipelineRunner:
  - Receives a learning callback / writer.
  - Emits LearningRecords as runs complete, including variant info.

### 6.3 Cluster

- LearningRuns can be distributed across cluster nodes.
- Each LearningRunStep maps cleanly to a **cluster job**, and results feed back into the same LearningRecord format.

---

## 7. External LLM Integration (Future)

LearningRecords are designed to be LLM‑friendly:

- Self‑contained JSONL lines with clear fields.
- No heavy binary payloads – only references to images on disk.

Future responsibilities of an external LLM could include:

- Suggesting new preset configs per pack.
- Suggesting learning plans (“Try varying Sampler between X and Y next.”).
- Explaining trends in human‑readable language.

These are **future PRs**; the v2 spec only ensures that records and structures are ready for that integration.

---

## 8. Non‑Goals

- No on‑device deep learning models for auto‑rating images (at least initially).
- No heavy analytics UI beyond basic tables and simple charts.
- No multi‑user learning; the system is optimized for a single operator/home lab setup.

---

## 9. Testing Expectations

- Unit tests for core data structures and serializers.
- Tests for LearningRunner stub behavior and pipeline hooks.
- Tests that ensure LearningRecords are written atomically and never corrupt on failure.
- Future tests for the Learning Run GUI (once implemented) using the GUI V2 harness.
