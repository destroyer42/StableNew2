"""Helper scripts package for legacy child-run workflows."""
